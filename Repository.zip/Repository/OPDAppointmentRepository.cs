﻿using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using WebApplicationSampleTest2.Models;

namespace WebApplicationSampleTest2.Repository
{
    public class OPDAppointmentRepository:IOPDAppointment
    {
        private readonly string _connectionString;

        public OPDAppointmentRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("MySqlConnection");
        }
        // Create appointment
        public void CreateAppointment(OPDAppointmentModel appointment, int hospitalId, int? subHospitalId)
        {
            try
            {
                using var conn = new MySqlConnection(_connectionString);
                using var cmd = new MySqlCommand("sp_OPDAppointment_Insert", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("p_PatientId", appointment.PatientId);
                cmd.Parameters.AddWithValue("p_HospitalId", hospitalId);
                //cmd.Parameters.AddWithValue("p_SubHospitalId", subHospitalId);
                cmd.Parameters.AddWithValue("p_SubHospitalId", (object?)subHospitalId ?? DBNull.Value);

                cmd.Parameters.AddWithValue("p_DoctorId", appointment.DoctorId);
                cmd.Parameters.AddWithValue("p_AppointmentDate", appointment.AppointmentDate);
                cmd.Parameters.AddWithValue("p_AppointmentTime", appointment.AppointmentTime);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Error while inserting hospital", ex);
            }
           
        }

        // Update appointment
        public int UpdateAppointment(OPDAppointmentModel appointment, int hospitalId, int? subHospitalId)
        {

            try
            {
                using var conn = new MySqlConnection(_connectionString);
                using var cmd = new MySqlCommand("sp_OPDAppointment_Update", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("p_Id", appointment.Id);
                cmd.Parameters.AddWithValue("p_PatientId", appointment.PatientId);
                cmd.Parameters.AddWithValue("p_HospitalId", hospitalId);
                cmd.Parameters.AddWithValue("p_SubHospitalId", (object?)subHospitalId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("p_DoctorId", appointment.DoctorId);
                cmd.Parameters.AddWithValue("p_AppointmentDate", appointment.AppointmentDate);
                cmd.Parameters.AddWithValue("p_AppointmentTime", appointment.AppointmentTime);
                cmd.Parameters.AddWithValue("p_IsActive", appointment.IsActive);

                conn.Open();
                return cmd.ExecuteNonQuery(); // returns number of rows affected
            }
            catch (Exception ex)
            {
                throw new Exception("Error while inserting hospital", ex);
            }
           
        }

        // Soft delete appointment
        public void DeleteAppointment(int appointmentId, int hospitalId, int? subHospitalId)
        {
            try
            {
                using var conn = new MySqlConnection(_connectionString);
                using var cmd = new MySqlCommand("sp_OPDAppointment_Delete", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("p_Id", appointmentId);
                cmd.Parameters.AddWithValue("p_HospitalId", hospitalId);
                //cmd.Parameters.AddWithValue("p_SubHospitalId", subHospitalId);
                cmd.Parameters.AddWithValue("p_SubHospitalId", (object?)subHospitalId ?? DBNull.Value);



                conn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Error while inserting hospital", ex);
            }
           
        }

        // Get appointment by Id
        public OPDAppointmentModel? GetAppointmentById(int appointmentId, int hospitalId, int? subHospitalId)
        {
            OPDAppointmentModel? appointment = null;
            try
            {
                using var conn = new MySqlConnection(_connectionString);
                using var cmd = new MySqlCommand("sp_OPDAppointment_GetById", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("p_Id", appointmentId);
                cmd.Parameters.AddWithValue("p_HospitalId", hospitalId);
                //cmd.Parameters.AddWithValue("p_SubHospitalId", subHospitalId);
                cmd.Parameters.AddWithValue("p_SubHospitalId", (object?)subHospitalId ?? DBNull.Value);


                conn.Open();
                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    appointment = new OPDAppointmentModel
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        PatientId = Convert.ToInt32(reader["PatientId"]),
                        DoctorId = Convert.ToInt32(reader["DoctorId"]),
                        HospitalId = Convert.ToInt32(reader["HospitalId"]),
                        //SubHospitalId = Convert.ToInt32(reader["SubHospitalId"]),
                        SubHospitalId = reader["SubHospitalId"] == DBNull.Value ? (int?)null : Convert.ToInt32(reader["SubHospitalId"]),
                        AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"]),
                        AppointmentTime = TimeSpan.Parse(reader["AppointmentTime"].ToString()),
                        IsActive = Convert.ToBoolean(reader["IsActive"]),
                        // ✅ FIX: Read IsWalkIn so walk-in saves redirect back to
                        // WalkInConsultation/Index instead of OPDAppointment/Index
                        IsWalkIn = ColumnExists(reader, "IsWalkIn")
                                   && reader["IsWalkIn"] != DBNull.Value
                                   && Convert.ToBoolean(reader["IsWalkIn"])
                    };
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error while inserting hospital", ex);
            }
            return appointment;
        }

        // Get all appointments
        public List<OPDAppointmentModel> GetAllAppointments(int hospitalId, int? subHospitalId)
        {
            var list = new List<OPDAppointmentModel>();
            try
            {
                using var conn = new MySqlConnection(_connectionString);
                using var cmd = new MySqlCommand("sp_OPDAppointment_GetAll", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("p_HospitalId", hospitalId);
                //cmd.Parameters.AddWithValue("p_SubHospitalId", subHospitalId);
                cmd.Parameters.AddWithValue("p_SubHospitalId", (object?)subHospitalId ?? DBNull.Value);


                conn.Open();
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new OPDAppointmentModel
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        PatientId = Convert.ToInt32(reader["PatientId"]),
                        DoctorId = Convert.ToInt32(reader["DoctorId"]),
                        HospitalId = Convert.ToInt32(reader["HospitalId"]),
                        //SubHospitalId = Convert.ToInt32(reader["SubHospitalId"]),
                        SubHospitalId = reader["SubHospitalId"] == DBNull.Value ? (int?)null : Convert.ToInt32(reader["SubHospitalId"]),

                        AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"]),
                        AppointmentTime = TimeSpan.Parse(reader["AppointmentTime"].ToString()),
                        IsActive = Convert.ToBoolean(reader["IsActive"]),
                        Status = reader["Status"].ToString(),
                        IsWalkIn = reader["IsWalkIn"] != DBNull.Value && Convert.ToBoolean(reader["IsWalkIn"])
                    });
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error while inserting hospital", ex);
            }
            return list;
        }

        public void UpdateStatus(int appointmentId, int hospitalId, int? subHospitalId, string status)
        {
            try
            {
                using var conn = new MySqlConnection(_connectionString);
                using var cmd = new MySqlCommand("sp_OPDAppointment_UpdateStatus", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                // 🔹 Add parameters
                cmd.Parameters.AddWithValue("p_AppointmentId", appointmentId);
                cmd.Parameters.AddWithValue("p_HospitalId", hospitalId);
                cmd.Parameters.AddWithValue("p_SubHospitalId", (object?)subHospitalId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("p_Status", status);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Error while inserting hospital", ex);
            }
            
        }

        public List<OPDMedicineVM> GetMedicinesByOPDId(int opdId)
        {
            List<OPDMedicineVM> list = new List<OPDMedicineVM>();
            try
            {
                using (MySqlConnection con = new MySqlConnection(_connectionString))
                {
                    using (MySqlCommand cmd = new MySqlCommand("sp_GetMedicinesByOPDId", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("p_OPDId", opdId);

                        con.Open();

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                list.Add(new OPDMedicineVM
                                {
                                    MedicineId = Convert.ToInt32(reader["Medicine_Id"]),
                                    MedicineName = reader["MedicineName"].ToString(),
                                    Morning = Convert.ToInt32(reader["Morning"]),
                                    Afternoon = Convert.ToInt32(reader["Afternoon"]),
                                    Evening = Convert.ToInt32(reader["Evening"]),
                                    Days = Convert.ToInt32(reader["Days"])
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error while inserting hospital", ex);
            }
            return list;
        }

        public List<OPD> GetPatientFullHistory(int patientId)
        {
            var opdList = new List<OPD>();
            try
            {
                using (var conn = new MySqlConnection(_connectionString))
                using (var cmd = new MySqlCommand("GetPatientFullHistory", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PatientId", patientId);

                    conn.Open();

                    using (var reader = cmd.ExecuteReader())
                    {
                        // 1️⃣ Read OPD visits
                        while (reader.Read())
                        {
                            opdList.Add(new OPD
                            {
                                Id = Convert.ToInt32(reader["OPDId"]),
                                AppointmentId = Convert.ToInt32(reader["AppointmentId"]),
                                AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"]),
                                BP = reader["BP"].ToString(),
                                Pulse = reader["Pulse"].ToString(),
                                Investigation = reader["Investigation"].ToString(),
                                ReportDetail = reader["ReportDetail"].ToString(),
                                ReportFilePath = reader["ReportFilePath"].ToString(),
                                NextAppointmentDate = reader["NextAppointmentDate"] != DBNull.Value
                                                      ? Convert.ToDateTime(reader["NextAppointmentDate"])
                                                      : (DateTime?)null
                            });
                        }

                        // 2️⃣ Read Symptoms
                        if (reader.NextResult())
                        {
                            while (reader.Read())
                            {
                                var opd = opdList.Find(x => x.Id == Convert.ToInt32(reader["OPD_Id"]));
                                if (opd != null)
                                {
                                    opd.Symptom.Add(reader["SymptomName"].ToString());
                                    // If you want full symptom details, you can also store OPDSymptomVM in a separate list
                                }
                            }
                        }

                        // 3️⃣ Read Medicines
                        if (reader.NextResult())
                        {
                            while (reader.Read())
                            {
                                var opd = opdList.Find(x => x.Id == Convert.ToInt32(reader["OPD_Id"]));
                                if (opd != null)
                                {
                                    opd.Medicines.Add(new OPDMedicine
                                    {
                                        MedicineName = reader["MedicineName"].ToString(),
                                        MedicineId = 0, // optional: you can pass Medicine_Id from SP if needed
                                        Morning = reader["Morning"].ToString(),
                                        Afternoon = reader["Afternoon"].ToString(),
                                        Evening = reader["Evening"].ToString(),
                                        Days = Convert.ToInt32(reader["Days"])
                                    });
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error while inserting hospital", ex);
            }

           

            return opdList;
        }

        // Helper: safely check whether a column exists in a data reader.
        // Prevents IndexOutOfRange/KeyNotFound crashes when a stored procedure
        // does not return a particular column.
        private static bool ColumnExists(IDataRecord reader, string columnName)
        {
            try
            {
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    if (string.Equals(reader.GetName(i), columnName, StringComparison.OrdinalIgnoreCase))
                        return true;
                }
            }
            catch
            {
                // If anything goes wrong while inspecting fields, treat as missing.
            }
            return false;
        }

        // ═══════════════════════════════════════════════════════════════════
        //  PERFORMANCE: BATCH QUERIES
        //  Replace N+1 round trips (per-appointment SP calls) with a single
        //  SQL query using a temp table / JOIN. This is the single biggest
        //  fix for the 4–5 second page/button delays when the list grows.
        // ═══════════════════════════════════════════════════════════════════

        public Dictionary<int, (int opdId, string ipdStatus)> GetOPDWithIPDStatusBatch(
            List<int> appointmentIds, int hospitalId, int? subHospitalId)
        {
            var result = new Dictionary<int, (int, string)>();
            if (appointmentIds == null || appointmentIds.Count == 0) return result;

            try
            {
                using var conn = new MySqlConnection(_connectionString);
                conn.Open();

                var idList = string.Join(",", appointmentIds);
                string subFilter = subHospitalId.HasValue
                    ? "AND SubHospital_Id = @SubHospitalId"
                    : "AND SubHospital_Id IS NULL";

                string sql = "SELECT o.Id AS OpdId, o.AppointmentId, a.Id AS ApptId " +
                    "FROM opdmaster o " +
                    "INNER JOIN (SELECT AppointmentId, MAX(Id) AS MaxId FROM opdmaster " +
                    "WHERE AppointmentId IN (" + idList + ") AND Hospital_Id = @HospitalId " +
                    subFilter + " GROUP BY AppointmentId) t ON o.Id = t.MaxId " +
                    "INNER JOIN opdappointment a ON a.Id = o.AppointmentId ORDER BY o.AppointmentId";

                using var cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@HospitalId", hospitalId);
                if (subHospitalId.HasValue)
                    cmd.Parameters.AddWithValue("@SubHospitalId", subHospitalId.Value);

                var opdByAppt = new Dictionary<int, int>();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        opdByAppt[Convert.ToInt32(reader["ApptId"])] = Convert.ToInt32(reader["OpdId"]);
                    }
                }

                if (opdByAppt.Count == 0) return result;

                var opdIds = opdByAppt.Values.Distinct().ToList();
                var opdIdList = string.Join(",", opdIds);
                string subFilter2 = subHospitalId.HasValue
                    ? "AND SubHospitalId = @SubHospitalId2"
                    : "AND (SubHospitalId IS NULL OR SubHospitalId IS NULL)";

                string sql2 = "SELECT OPDVisitId, Status FROM ipdadmission " +
                    "WHERE OPDVisitId IN (" + opdIdList + ") " +
                    "AND ParentHospitalId = @HospitalId2 " +
                    subFilter2 + " AND IsActiveAdmission = 1 ORDER BY IPDId DESC";

                var statusByOpd = new Dictionary<int, string>();
                using (var cmd2 = new MySqlCommand(sql2, conn))
                {
                    cmd2.Parameters.AddWithValue("@HospitalId2", hospitalId);
                    if (subHospitalId.HasValue)
                        cmd2.Parameters.AddWithValue("@SubHospitalId2", subHospitalId.Value);

                    using var reader = cmd2.ExecuteReader();
                    while (reader.Read())
                    {
                        int opd = reader.IsDBNull(reader.GetOrdinal("OPDVisitId")) ? 0 : Convert.ToInt32(reader["OPDVisitId"]);
                        string st = reader["Status"]?.ToString() ?? "";
                        if (opd > 0 && !statusByOpd.ContainsKey(opd)) statusByOpd[opd] = st;
                    }
                }

                foreach (var kvp in opdByAppt)
                {
                    statusByOpd.TryGetValue(kvp.Value, out var st);
                    result[kvp.Key] = (kvp.Value, st);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("BATCH_FAIL: " + ex.Message);
            }
            return result;
        }

        public Dictionary<int, string> GetSymptomsByOPDIds(List<int> opdIds)
        {
            var result = new Dictionary<int, string>();
            if (opdIds == null || opdIds.Count == 0) return result;

            try
            {
                var idList = string.Join(",", opdIds);
                string sql = "SELECT os.OPD_Id, GROUP_CONCAT(s.SymptomName SEPARATOR ', ') AS SymptomNames " +
                    "FROM opdsymptom os INNER JOIN symptoms s ON s.SymptomId = os.Symptom_Id " +
                    "WHERE os.OPD_Id IN (" + idList + ") AND os.IsActive = 1 GROUP BY os.OPD_Id";

                using var conn = new MySqlConnection(_connectionString);
                conn.Open();
                using var cmd = new MySqlCommand(sql, conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    result[Convert.ToInt32(reader["OPD_Id"])] = reader["SymptomNames"]?.ToString() ?? "";
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("SYMPTOMS_BATCH_FAIL: " + ex.Message);
            }
            return result;
        }

        public int GetTodayTokenNumber(int appointmentId, int hospitalId, int? subHospitalId)
        {
            try
            {
                using var conn = new MySqlConnection(_connectionString);
                conn.Open();

                string subFilter = subHospitalId.HasValue
                    ? "AND SubHospitalId = @SubHospitalId"
                    : "AND (SubHospitalId IS NULL OR SubHospitalId = 0)";

                string sql = "SELECT Token FROM ( " +
                    "SELECT Id, ROW_NUMBER() OVER ( " +
                    "PARTITION BY AppointmentDate ORDER BY AppointmentDate, AppointmentTime, Id " +
                    ") AS Token FROM opdappointment " +
                    "WHERE AppointmentDate = CURDATE() AND HospitalId = @HospitalId " +
                    subFilter + " AND IsActive = 1 " +
                    ") t WHERE t.Id = @AppointmentId";

                using var cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@HospitalId", hospitalId);
                cmd.Parameters.AddWithValue("@AppointmentId", appointmentId);
                if (subHospitalId.HasValue)
                    cmd.Parameters.AddWithValue("@SubHospitalId", subHospitalId.Value);

                var result = cmd.ExecuteScalar();
                return result == null || result == DBNull.Value ? 0 : Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("TOKEN_FAIL: " + ex.Message);
                return 0;
            }
        }
    }
}
